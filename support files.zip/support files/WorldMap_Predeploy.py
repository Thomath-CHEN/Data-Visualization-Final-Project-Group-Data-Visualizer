import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import geopandas as gpd
import os

# You can change to your own directory here
os.chdir('E:/硕士学习/第二年第二学期/Data Visualization/Assignment3/webpage files')

# 131 Countries, 10 lines per Country, 10 years studied
df = pd.read_csv("FFG_Hackathon_Country_Level_Data.csv")

## calculate the percentage of CO2 by sector
data_transportation = df[["Year","Country Name","Country Code","EN.ATM.CO2E.KT","EN.CO2.TRAN.ZS","EN.CO2.MANF.ZS","EN.CO2.BLDG.ZS","EN.CO2.OTHX.ZS","EG.ELC.HYRO.ZS", 'EG.USE.COMM.CL.ZS', 'EG.ELC.FOSL.ZS','EG.FEC.RNEW.ZS']]
data_transportation["CO2E_by_transport"] = data_transportation["EN.ATM.CO2E.KT"]*(data_transportation["EN.CO2.TRAN.ZS"])/100
data_transportation["CO2E_by_manufacturing"] = data_transportation["EN.ATM.CO2E.KT"]*(data_transportation["EN.CO2.MANF.ZS"])/100
data_transportation["CO2E_by_commerce"] = data_transportation["EN.ATM.CO2E.KT"]*(data_transportation["EN.CO2.BLDG.ZS"])/100
data_transportation["CO2E_by_others"] = data_transportation["EN.ATM.CO2E.KT"]*(data_transportation["EN.CO2.OTHX.ZS"])/100

## get the coordinates of each country from external source
world_filepath = gpd.datasets.get_path('naturalearth_lowres')
gdf = gpd.read_file(world_filepath)

gdf.rename(columns={"name":"Country Name"}, inplace=True)

## correct the countries'names that are inconsistent
gdf.loc[gdf['Country Name']=='United States of America', 'Country Name']='United States'
gdf.loc[gdf['Country Name']=='Russia', 'Country Name']='Russian Federation'
gdf.loc[gdf['Country Name']=='Dem. Rep. Congo', 'Country Name']='Congo, Dem. Rep.'
gdf.loc[gdf['Country Name']=='Dominican Rep.', 'Country Name']='Dominican Republic.'
gdf.loc[gdf['Country Name']=='Bosnia and Herz.', 'Country Name']='Bosnia and Herzegovina'
gdf.loc[gdf['Country Name']=='Brunei', 'Country Name']='Brunei Darussalam'
gdf.loc[gdf['Country Name']=="Côte d'Ivoire", 'Country Name']="Cote d'Ivoire"
gdf.loc[gdf['Country Name']=="Egypt", 'Country Name']="Egypt, Arab Rep."
gdf.loc[gdf['Country Name']=="South Korea", 'Country Name']="Korea, Rep."
gdf.loc[gdf['Country Name']=="Venezuela", 'Country Name']="Venezuela, RB"


## join our data with the external data to get the geographic cooridnates of each country
gdf_joined = gdf.set_index("Country Name").join(data_transportation.set_index("Country Name"),how="right")
gdf_joined.dropna().info()
gdf_joined.dropna(inplace=True)


## rename columns so they are moer readable
gdf_joined.rename(columns={
    "EN.CO2.TRAN.ZS":"% of CO2 emissions in Transport",
    "EN.CO2.MANF.ZS":"% of CO2 emissions in Manufacturing",
    "EN.CO2.BLDG.ZS":"% of CO2 emissions in Commerce",
    "EN.CO2.OTHX.ZS":"% of CO2 emissions in Other Sectors",
    "EG.ELC.HYRO.ZS":"% of electric production by HydroElectric Sources",
    "EG.USE.COMM.CL.ZS":"% of total energy used in Nuclear Energy",
    "EG.ELC.FOSL.ZS":"% of electric production by oil,gas,and coal",
    "EG.FEC.RNEW.ZS":"% of electric production by renewables",
    "EN.ATM.CO2E.KT":"Total CO2 emissions"
},inplace=True)

gdf_joined["% CO2 emission change in Transport"] = ((gdf_joined[gdf_joined.Year == 2014]["CO2E_by_transport"] - gdf_joined[gdf_joined.Year == 2007]["CO2E_by_transport"])/ gdf_joined[gdf_joined.Year == 2007]["CO2E_by_transport"])
gdf_joined["% CO2 emission change in Manfacturing"] = ((gdf_joined[gdf_joined.Year == 2014]["CO2E_by_manufacturing"] - gdf_joined[gdf_joined.Year == 2007]["CO2E_by_manufacturing"])/ gdf_joined[gdf_joined.Year == 2007]["CO2E_by_manufacturing"])
gdf_joined["% CO2 emission change in Commerce"] = ((gdf_joined[gdf_joined.Year == 2014]["CO2E_by_commerce"] - gdf_joined[gdf_joined.Year == 2007]["CO2E_by_commerce"])/ gdf_joined[gdf_joined.Year == 2007]["CO2E_by_commerce"])
gdf_joined["% CO2 emission change in Other Sector"] = ((gdf_joined[gdf_joined.Year == 2014]["CO2E_by_others"] - gdf_joined[gdf_joined.Year == 2007]["CO2E_by_others"])/ gdf_joined[gdf_joined.Year == 2007]["CO2E_by_others"])


## create HTML graphs with plotly and save them locally
maptransPct = px.choropleth(gdf_joined, hover_name=gdf_joined.index, geojson=gdf_joined.set_index("Country Code"), locations="Country Code", animation_frame="Year", color="% of CO2 emissions in Transport", color_continuous_scale="blues" )
maptransPct.write_html("CO2byTransportMap%.html")

mapCommPct = px.choropleth(gdf_joined, hover_name=gdf_joined.index, geojson=gdf_joined.set_index("Country Code"), locations="Country Code", animation_frame="Year", color="% of CO2 emissions in Commerce", color_continuous_scale="blues" )
mapCommPct.write_html("CO2byCommerceMap%.html")

mapManPct = px.choropleth(gdf_joined, hover_name=gdf_joined.index, geojson=gdf_joined.set_index("Country Code"), locations="Country Code", animation_frame="Year", color="% of CO2 emissions in Manufacturing", color_continuous_scale="blues" )
mapManPct.write_html("CO2byManufacturingMap%.html")

mapOtherPct = px.choropleth(gdf_joined, hover_name=gdf_joined.index, geojson=gdf_joined.set_index("Country Code"), locations="Country Code", animation_frame="Year", color="% of CO2 emissions in Other Sectors", color_continuous_scale="blues" )
mapOtherPct.write_html("CO2byOthergMap%.html")

